import React from 'react';
import { Plus, DollarSign } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { useQuery } from '@tanstack/react-query';
import { useChatContext } from '@/providers/ChatContext';
import { formatRelativeTime } from '@/lib/utils';
import { Conversation } from '@/types';
import { getBudgetSummary } from '@/lib/openai';

interface SidebarProps {
  className?: string;
  onClose?: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ className = '', onClose }) => {
  const { 
    conversations, 
    activeConversationId, 
    setActiveConversation, 
    createConversation 
  } = useChatContext();

  const { data: budgetData } = useQuery({
    queryKey: ['/api/budget'],
    staleTime: 60000 // 1 minute
  });

  const handleConversationClick = (conversation: Conversation) => {
    setActiveConversation(conversation.id);
    if (onClose) onClose();
  };

  const handleNewConversation = () => {
    createConversation();
    if (onClose) onClose();
  };

  // Format budget data for display
  const budgetSummary = budgetData?.summary;
  const formatCurrency = (amount: number) => `$${(amount / 100).toFixed(2)}`;
  const budgetUsedPercent = budgetSummary ? Math.min(100, budgetSummary.percentUsed) : 0;

  return (
    <div className={`flex flex-col h-full bg-white border-r border-gray-200 ${className}`}>
      <div className="flex items-center justify-between px-6 py-4 border-b border-gray-200">
        <div className="flex items-center space-x-2">
          <DollarSign className="h-7 w-7 text-primary" />
          <h1 className="text-xl font-semibold text-text">BudgetBot</h1>
        </div>
      </div>
      
      {/* Financial Overview */}
      <div className="px-4 py-3 border-b border-gray-200">
        <h2 className="text-sm font-medium text-text-light px-2 mb-2">Financial Overview</h2>
        <div className="bg-gray-50 rounded-lg p-4 shadow-sm">
          <div className="mb-4">
            <div className="flex justify-between mb-1">
              <span className="text-sm font-medium">Monthly Budget</span>
              <span className="text-sm font-medium">
                {budgetSummary 
                  ? `${formatCurrency(budgetSummary.totalSpent)} / ${formatCurrency(budgetSummary.totalBudget)}`
                  : 'Loading...'}
              </span>
            </div>
            <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
              <div 
                className="h-full bg-primary" 
                style={{ width: `${budgetUsedPercent}%` }}
              ></div>
            </div>
          </div>
          
          <div className="flex justify-between text-sm">
            <div>
              <p className="text-text-light">Top Category</p>
              <p className="font-medium">
                {budgetSummary && Object.entries(budgetSummary.spentByCategory).length > 0
                  ? Object.entries(budgetSummary.spentByCategory)
                      .sort((a, b) => b[1] - a[1])[0][0]
                  : 'None'}
              </p>
            </div>
            <div className="text-right">
              <p className="text-text-light">Available</p>
              <p className="font-medium text-primary">
                {budgetSummary 
                  ? formatCurrency(budgetSummary.remaining)
                  : 'Loading...'}
              </p>
            </div>
          </div>
        </div>
      </div>
      
      {/* Conversations List */}
      <div className="flex-1 overflow-y-auto">
        <div className="px-4 py-3">
          <h2 className="text-sm font-medium text-text-light px-2 mb-2">Conversations</h2>
          <div className="space-y-1">
            {conversations.map((conversation) => (
              <div 
                key={conversation.id}
                className={`px-2 py-3 hover:bg-gray-50 rounded-lg cursor-pointer 
                  ${activeConversationId === conversation.id 
                    ? 'border-l-2 border-primary' 
                    : ''}`}
                onClick={() => handleConversationClick(conversation)}
              >
                <h3 className="font-medium text-sm truncate">{conversation.title}</h3>
                <p className="text-xs text-text-light truncate">
                  {/* Show preview of last message here if available */}
                </p>
                <p className="text-xs text-text-light mt-1">
                  {formatRelativeTime(new Date(conversation.updatedAt))}
                </p>
              </div>
            ))}
            
            {conversations.length === 0 && (
              <div className="px-2 py-4 text-center text-sm text-text-light">
                No conversations yet
              </div>
            )}
          </div>
        </div>
      </div>
      
      {/* New Conversation Button */}
      <div className="border-t border-gray-200 p-4">
        <Button 
          variant="outline" 
          className="w-full flex items-center justify-center space-x-2 text-text-light"
          onClick={handleNewConversation}
        >
          <Plus size={16} />
          <span>New Conversation</span>
        </Button>
      </div>
    </div>
  );
};

export default Sidebar;
