import React, { useEffect, useRef } from 'react';
import { useChatContext } from '@/providers/ChatContext';
import MessageBubble from './MessageBubble';
import ExpenseCard from './ExpenseCard';
import BudgetAnalysisCard from './BudgetAnalysisCard';
import { PlusCircle, DollarSign } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useQuery } from '@tanstack/react-query';

const ChatMessages: React.FC = () => {
  const { messages, sendMessage, activeConversationId, isFirstLoad } = useChatContext();
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  const { data: budgetData } = useQuery({
    queryKey: ['/api/budget'],
    staleTime: 60000 // 1 minute
  });

  // Scroll to bottom when messages change
  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages]);

  // Handle suggested message clicks
  const handleSuggestedMessageClick = (text: string) => {
    if (activeConversationId) {
      sendMessage(activeConversationId, text);
    }
  };

  // Check if we need to show the welcome card (no messages or first load)
  const showWelcomeCard = messages.length === 0 || isFirstLoad;

  return (
    <div 
      ref={containerRef}
      className="flex-1 overflow-y-auto p-4 md:px-6"
      id="chat-container"
    >
      {/* Welcome Card */}
      {showWelcomeCard && (
        <div className="flex justify-center mb-6">
          <div className="bg-white border border-gray-200 p-6 rounded-xl shadow-sm max-w-md w-full">
            <div className="flex justify-center mb-4">
              <div className="w-12 h-12 rounded-full bg-primary flex items-center justify-center">
                <DollarSign className="h-6 w-6 text-white" />
              </div>
            </div>
            <h2 className="text-xl font-semibold text-center mb-2">Welcome to BudgetBot</h2>
            <p className="text-center text-gray-600 mb-4">
              Your AI-powered financial assistant. Ask me about budgeting, track expenses, or get financial insights.
            </p>
            <div className="flex flex-wrap gap-2 justify-center">
              <Button 
                variant="outline" 
                size="sm"
                className="text-sm"
                onClick={() => handleSuggestedMessageClick("Set up a budget for me")}
              >
                Set up a budget
              </Button>
              <Button 
                variant="outline" 
                size="sm"
                className="text-sm"
                onClick={() => handleSuggestedMessageClick("Track my spending")}
              >
                Track my spending
              </Button>
              <Button 
                variant="outline" 
                size="sm"
                className="text-sm"
                onClick={() => handleSuggestedMessageClick("Give me some saving tips")}
              >
                Saving tips
              </Button>
            </div>
          </div>
        </div>
      )}
      
      {/* Chat Messages */}
      <div className="space-y-4">
        {messages.map((message, index) => {
          // Check if this message might contain expense data
          const containsExpense = 
            message.type === "bot" && 
            message.content.toLowerCase().includes("expense") &&
            message.content.toLowerCase().includes("recorded");

          // Check if this message might contain budget analysis
          const containsBudgetAnalysis = 
            message.type === "bot" && 
            message.content.toLowerCase().includes("budget analysis") &&
            budgetData;

          return (
            <div key={message.id ?? index}>
              <MessageBubble message={message} />
              
              {/* Show expense card if message likely contains expense data */}
              {containsExpense && budgetData?.expenses && (
                <ExpenseCard expenses={budgetData.expenses.slice(0, 5)} />
              )}
              
              {/* Show budget analysis card if message contains budget analysis */}
              {containsBudgetAnalysis && budgetData && (
                <BudgetAnalysisCard budgetData={budgetData} />
              )}
            </div>
          );
        })}

        {/* An empty div for scrolling to bottom */}
        <div ref={messagesEndRef} />
      </div>
    </div>
  );
};

export default ChatMessages;
