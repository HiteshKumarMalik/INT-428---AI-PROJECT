import React from 'react';
import { Message } from '@/types';
import { DollarSign, User } from 'lucide-react';

interface MessageBubbleProps {
  message: Message;
}

const MessageBubble: React.FC<MessageBubbleProps> = ({ message }) => {
  const isBot = message.type === 'bot';
  
  return (
    <div className={`flex items-end ${isBot ? '' : 'justify-end'}`}>
      {isBot && (
        <div className="flex-shrink-0 mr-2">
          <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center">
            <DollarSign className="h-4 w-4 text-white" />
          </div>
        </div>
      )}
      
      <div 
        className={`chat-message p-3 shadow-sm max-w-[85%] rounded-t-lg ${
          isBot 
            ? 'bg-primary text-white rounded-br-lg rounded-bl-none' 
            : 'bg-gray-100 text-gray-800 rounded-bl-lg rounded-br-none'
        }`}
      >
        <p className="whitespace-pre-line">{message.content}</p>
      </div>
    </div>
  );
};

export default MessageBubble;
