import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Check } from 'lucide-react';

interface BudgetAnalysisCardProps {
  budgetData: {
    budget: any;
    expenses: any[];
    summary: {
      totalBudget: number;
      totalSpent: number;
      remaining: number;
      percentUsed: number;
      spentByCategory: Record<string, number>;
    };
  };
}

const BudgetAnalysisCard: React.FC<BudgetAnalysisCardProps> = ({ budgetData }) => {
  const { summary } = budgetData;
  
  // Format currency
  const formatCurrency = (amount: number) => `$${(amount / 100).toFixed(2)}`;
  
  // Get categories with spending
  const categoriesWithSpending = Object.entries(summary.spentByCategory)
    .map(([category, amount]) => ({
      category,
      amount,
      percentage: (amount / summary.totalSpent) * 100
    }))
    .sort((a, b) => b.amount - a.amount);
  
  return (
    <Card className="mt-2 mb-4 ml-10 max-w-[85%]">
      <CardHeader className="pb-2">
        <CardTitle className="text-sm">Monthly Budget Analysis</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 gap-4 mb-4">
          <div className="bg-gray-50 p-3 rounded-lg">
            <p className="text-xs text-gray-500 mb-1">Total Spent</p>
            <p className="text-lg font-semibold">{formatCurrency(summary.totalSpent)}</p>
          </div>
          <div className="bg-gray-50 p-3 rounded-lg">
            <p className="text-xs text-gray-500 mb-1">Remaining Budget</p>
            <p className="text-lg font-semibold text-primary">{formatCurrency(summary.remaining)}</p>
          </div>
        </div>
        
        <h4 className="text-xs font-medium text-gray-500 mb-2">Spending By Category</h4>
        <div className="space-y-3">
          {categoriesWithSpending.map(({ category, amount, percentage }) => (
            <div key={category}>
              <div className="flex justify-between text-xs mb-1">
                <span>{category}</span>
                <span>{formatCurrency(amount)} ({percentage.toFixed(0)}%)</span>
              </div>
              <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-primary" 
                  style={{ width: `${percentage}%` }}
                ></div>
              </div>
            </div>
          ))}
          
          {categoriesWithSpending.length === 0 && (
            <p className="text-xs text-gray-500">No spending recorded yet</p>
          )}
        </div>
        
        <div className="mt-4 pt-3 border-t border-gray-100">
          <h4 className="text-xs font-medium text-gray-500 mb-2">Budget Health</h4>
          <div className="flex items-center">
            <Check className="h-5 w-5 text-green-500 mr-2" />
            <p className="text-sm">
              {summary.percentUsed < 80 
                ? `Your spending is on track! You've used ${summary.percentUsed.toFixed(0)}% of your monthly budget.`
                : `You've used ${summary.percentUsed.toFixed(0)}% of your monthly budget.`}
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default BudgetAnalysisCard;
