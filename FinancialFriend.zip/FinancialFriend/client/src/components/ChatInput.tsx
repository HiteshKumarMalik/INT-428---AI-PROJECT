import React, { useState, FormEvent, KeyboardEvent } from 'react';
import { SendHorizontal } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useChatContext } from '@/providers/ChatContext';

const ChatInput: React.FC = () => {
  const [message, setMessage] = useState('');
  const { activeConversationId, sendMessage, isLoading } = useChatContext();

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!message.trim() || !activeConversationId || isLoading) return;
    
    try {
      await sendMessage(activeConversationId, message.trim());
      setMessage('');
    } catch (error) {
      console.error('Failed to send message:', error);
    }
  };

  const handleKeyDown = (e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit(e);
    }
  };

  return (
    <div className="border-t border-gray-200 p-4 bg-white">
      <div className="max-w-4xl mx-auto relative">
        <form 
          className="relative rounded-xl shadow-sm bg-white" 
          onSubmit={handleSubmit}
        >
          <Input
            type="text"
            className="block w-full rounded-xl py-3 pl-4 pr-12 text-text placeholder:text-gray-400 focus:ring-2 focus:ring-primary/50"
            placeholder="Ask anything about your finances..."
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            onKeyDown={handleKeyDown}
            disabled={isLoading || !activeConversationId}
          />
          <Button 
            type="submit" 
            size="sm"
            variant="ghost"
            className="absolute inset-y-0 right-0 flex items-center pr-3 text-primary hover:text-primary-dark"
            disabled={isLoading || !activeConversationId}
          >
            <SendHorizontal className="h-5 w-5" />
          </Button>
        </form>
        <div className="text-xs text-center text-text-light mt-2">
          BudgetBot is here to help with finances, not provide professional investment advice.
        </div>
      </div>
    </div>
  );
};

export default ChatInput;
