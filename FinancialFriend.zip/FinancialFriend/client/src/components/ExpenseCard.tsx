import React from 'react';
import { ShoppingCart, Car } from 'lucide-react';
import { Expense } from '@/types';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { format } from 'date-fns';

interface ExpenseCardProps {
  expenses: Expense[];
}

const ExpenseCard: React.FC<ExpenseCardProps> = ({ expenses }) => {
  if (!expenses || expenses.length === 0) return null;
  
  // Format currency
  const formatCurrency = (amount: number) => `$${(amount / 100).toFixed(2)}`;
  
  // Get icon based on category
  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'Food & Dining':
        return <ShoppingCart className="h-4 w-4 text-blue-600" />;
      case 'Transportation':
        return <Car className="h-4 w-4 text-green-600" />;
      default:
        return <ShoppingCart className="h-4 w-4 text-blue-600" />;
    }
  };
  
  // Calculate total
  const totalSpent = expenses.reduce((sum, expense) => sum + expense.amount, 0);
  
  return (
    <Card className="mt-2 mb-4 ml-10 max-w-[85%]">
      <CardHeader className="pb-2">
        <CardTitle className="text-sm">Recent Expenses</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {expenses.map((expense, index) => (
            <div 
              key={expense.id}
              className={`flex justify-between items-center ${
                index < expenses.length - 1 ? 'pb-2 border-b border-gray-100' : ''
              }`}
            >
              <div className="flex items-center">
                <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center mr-3">
                  {getCategoryIcon(expense.category)}
                </div>
                <div>
                  <p className="text-sm font-medium">{expense.description}</p>
                  <p className="text-xs text-gray-500">
                    {format(new Date(expense.date), 'MMM d')}
                  </p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-sm font-medium">{formatCurrency(expense.amount)}</p>
                <p className="text-xs text-primary">{expense.category}</p>
              </div>
            </div>
          ))}
        </div>
        
        <div className="mt-4 pt-3 border-t border-gray-100 flex justify-between">
          <p className="text-sm font-medium">Total Spent</p>
          <p className="text-sm font-medium">{formatCurrency(totalSpent)}</p>
        </div>
      </CardContent>
    </Card>
  );
};

export default ExpenseCard;
