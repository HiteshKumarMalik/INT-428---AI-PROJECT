import React from 'react';
import AppLayout from '@/components/AppLayout';
import ChatMessages from '@/components/ChatMessages';
import ChatInput from '@/components/ChatInput';
import { useChatContext } from '@/providers/ChatContext';

const Chat: React.FC = () => {
  const { isLoading } = useChatContext();
  
  return (
    <AppLayout>
      <div className="flex-1 flex flex-col h-full overflow-hidden">
        <ChatMessages />
        <ChatInput />
      </div>
    </AppLayout>
  );
};

export default Chat;
