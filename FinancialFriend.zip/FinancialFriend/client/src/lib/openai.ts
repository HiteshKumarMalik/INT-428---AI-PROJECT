import { apiRequest } from "@/lib/queryClient";
import { Message, Conversation, Expense } from "@/types";

export async function sendMessage(
  conversationId: number,
  content: string
): Promise<{
  userMessage: Message;
  botMessage: Message;
  expenses?: Expense[];
}> {
  const response = await apiRequest("POST", "/api/messages", {
    conversationId,
    content,
    type: "user",
  });
  return await response.json();
}

export async function createNewConversation(
  title: string = "New Conversation"
): Promise<Conversation> {
  const response = await apiRequest("POST", "/api/conversations", { title });
  return await response.json();
}

export async function getConversations(): Promise<Conversation[]> {
  const response = await apiRequest("GET", "/api/conversations");
  return await response.json();
}

export async function getConversation(
  id: number
): Promise<{ conversation: Conversation; messages: Message[] }> {
  const response = await apiRequest("GET", `/api/conversations/${id}`);
  return await response.json();
}

export async function getBudgetSummary(): Promise<{
  budget: any;
  expenses: Expense[];
  summary: {
    totalBudget: number;
    totalSpent: number;
    remaining: number;
    percentUsed: number;
    spentByCategory: Record<string, number>;
  };
}> {
  const response = await apiRequest("GET", "/api/budget");
  return await response.json();
}
