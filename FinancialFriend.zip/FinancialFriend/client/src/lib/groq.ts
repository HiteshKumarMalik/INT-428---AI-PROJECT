import OpenAI from 'openai';

// Initialize OpenAI client (using Groq API)
const openai = new OpenAI({
  apiKey: import.meta.env.VITE_GROQ_API_KEY || '',
  baseURL: "https://api.groq.com/openai/v1"
});

// Function to analyze text with Groq API
export async function analyzeText(text: string): Promise<string> {
  try {
    const response = await openai.chat.completions.create({
      model: "llama3-70b-8192", // Using LLaMA 3 model
      messages: [
        {
          role: "system" as const,
          content: "You are a financial assistant helping analyze expenses and provide budgeting advice. Respond with helpful, concise information."
        },
        {
          role: "user" as const,
          content: text
        }
      ],
      temperature: 0.3,
      max_tokens: 1024,
    });

    return response.choices[0].message.content || "Sorry, I couldn't analyze your request.";
  } catch (error: any) {
    console.error("Error analyzing text with Groq:", error);
    throw new Error(`Failed to analyze with Groq: ${error.message}`);
  }
}

// Function to detect expenses in text
export async function detectExpenses(text: string): Promise<any[]> {
  try {
    const prompt = `
      Analyze the following text and extract any expense information in JSON format.
      For each expense found, include:
      - amount (in cents)
      - category (choose from: Food & Dining, Transportation, Housing, Entertainment, Shopping, Utilities, Healthcare, Travel, Education, Personal Care, or Other)
      - description (short description of the expense)
      - date (in YYYY-MM-DD format, use today's date if not specified)
      
      Text to analyze: "${text}"
      
      Return ONLY a valid JSON array of expense objects, with no additional text.
      If no expenses are found, return an empty array [].
    `;

    const response = await openai.chat.completions.create({
      model: "llama3-70b-8192",
      messages: [
        {
          role: "system" as const,
          content: "You are a specialized financial parser that extracts expense data from user messages."
        },
        {
          role: "user" as const,
          content: prompt
        }
      ],
      temperature: 0.1,
      max_tokens: 1024,
      response_format: { type: "json_object" }
    });

    const content = response.choices[0].message.content || "[]";
    // Try to parse the response as JSON
    try {
      const result = JSON.parse(content);
      return Array.isArray(result) ? result : (result.expenses || []);
    } catch (parseError) {
      console.error("Failed to parse Groq expense detection response:", parseError);
      return [];
    }
  } catch (error: any) {
    console.error("Error detecting expenses with Groq:", error);
    return [];
  }
}

// Function to generate budget recommendations
export async function generateBudgetRecommendations(expenses: any[], income?: number): Promise<string> {
  try {
    const totalSpent = expenses.reduce((sum, expense) => sum + expense.amount, 0);
    const expensesByCategory = expenses.reduce((acc: Record<string, number>, expense) => {
      const category = expense.category;
      acc[category] = (acc[category] || 0) + expense.amount;
      return acc;
    }, {});

    const prompt = `
      Based on the following expense data, provide budget recommendations:
      
      Total Spent: $${(totalSpent / 100).toFixed(2)}
      Spending by Category:
      ${Object.entries(expensesByCategory)
        .map(([category, amount]) => `- ${category}: $${(amount as number / 100).toFixed(2)}`)
        .join('\n')}
      ${income ? `Monthly Income: $${(income / 100).toFixed(2)}` : ''}
      
      Provide practical advice for budgeting, including:
      1. Areas where spending could be reduced
      2. Suggested budget allocations by category
      3. General financial tips
    `;

    const response = await openai.chat.completions.create({
      model: "llama3-70b-8192",
      messages: [
        {
          role: "system" as const,
          content: "You are a financial advisor specializing in personal budgeting. Provide helpful, practical advice."
        },
        {
          role: "user" as const,
          content: prompt
        }
      ],
      temperature: 0.5,
      max_tokens: 1024
    });

    return response.choices[0].message.content || "Sorry, I couldn't generate budget recommendations.";
  } catch (error: any) {
    console.error("Error generating budget recommendations with Groq:", error);
    throw new Error(`Failed to generate budget recommendations: ${error.message}`);
  }
}