import React, { createContext, useContext, useState, useEffect } from 'react';
import { useToast } from '@/hooks/use-toast';
import { Message, Conversation } from '@/types';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { sendMessage as apiSendMessage, createNewConversation, getConversations, getConversation } from '@/lib/openai';

interface ChatContextProps {
  messages: Message[];
  conversations: Conversation[];
  activeConversationId: number | null;
  isLoading: boolean;
  isFirstLoad: boolean;
  sendMessage: (conversationId: number, content: string) => Promise<void>;
  createConversation: () => Promise<void>;
  setActiveConversation: (conversationId: number) => void;
}

const ChatContext = createContext<ChatContextProps>({
  messages: [],
  conversations: [],
  activeConversationId: null,
  isLoading: false,
  isFirstLoad: true,
  sendMessage: async () => {},
  createConversation: async () => {},
  setActiveConversation: () => {},
});

export const useChatContext = () => useContext(ChatContext);

interface ChatProviderProps {
  children: React.ReactNode;
}

export const ChatProvider: React.FC<ChatProviderProps> = ({ children }) => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [activeConversationId, setActiveConversationId] = useState<number | null>(null);
  const [isFirstLoad, setIsFirstLoad] = useState(true);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch conversations
  const { 
    data: conversations = [],
    isLoading: isLoadingConversations
  } = useQuery({
    queryKey: ['/api/conversations'],
    staleTime: 30000, // 30 seconds
  });

  // Set the first conversation as active if there is one and no active one is set
  useEffect(() => {
    if (conversations.length > 0 && !activeConversationId && !isLoadingConversations) {
      setActiveConversation(conversations[0].id);
    }
  }, [conversations, activeConversationId, isLoadingConversations]);

  // Fetch messages when conversation changes
  useEffect(() => {
    if (activeConversationId) {
      // Fetch messages for this conversation
      queryClient.fetchQuery({
        queryKey: [`/api/conversations/${activeConversationId}`],
        staleTime: 30000, // 30 seconds
      }).then((data) => {
        if (data?.messages) {
          setMessages(data.messages);
          setIsFirstLoad(false);
        }
      });
    } else {
      setMessages([]);
    }
  }, [activeConversationId, queryClient]);

  // Send message mutation
  const sendMessageMutation = useMutation({
    mutationFn: ({ conversationId, content }: { conversationId: number, content: string }) => 
      apiSendMessage(conversationId, content),
    onSuccess: (data) => {
      // Update messages with new user and bot messages
      setMessages(prevMessages => [
        ...prevMessages,
        data.userMessage,
        data.botMessage
      ]);
      
      // If expenses were detected, invalidate budget data
      if (data.expenses && data.expenses.length > 0) {
        queryClient.invalidateQueries({ queryKey: ['/api/budget'] });
      }
      
      // Update conversation list since timestamps changed
      queryClient.invalidateQueries({ queryKey: ['/api/conversations'] });
    },
    onError: (error) => {
      toast({
        title: "Error sending message",
        description: "There was an error processing your message. Please try again.",
        variant: "destructive",
      });
      console.error("Message error:", error);
    },
  });

  // Create conversation mutation
  const createConversationMutation = useMutation({
    mutationFn: () => createNewConversation(),
    onSuccess: (newConversation) => {
      queryClient.invalidateQueries({ queryKey: ['/api/conversations'] });
      setActiveConversation(newConversation.id);
      toast({
        title: "New conversation started",
        description: "You can now start chatting!",
      });
    },
    onError: (error) => {
      toast({
        title: "Error creating conversation",
        description: "Failed to start a new conversation. Please try again.",
        variant: "destructive",
      });
      console.error("Conversation creation error:", error);
    },
  });

  const sendMessage = async (conversationId: number, content: string) => {
    await sendMessageMutation.mutateAsync({ conversationId, content });
  };

  const createConversation = async () => {
    await createConversationMutation.mutateAsync();
  };

  const setActiveConversation = (conversationId: number) => {
    setActiveConversationId(conversationId);
  };

  const value = {
    messages,
    conversations,
    activeConversationId,
    isLoading: sendMessageMutation.isPending || createConversationMutation.isPending,
    isFirstLoad,
    sendMessage,
    createConversation,
    setActiveConversation,
  };

  return <ChatContext.Provider value={value}>{children}</ChatContext.Provider>;
};
