// Message types
export type MessageType = "user" | "bot";

export interface Message {
  id: number;
  conversationId: number;
  content: string;
  type: MessageType;
  createdAt: string;
}

export interface Conversation {
  id: number;
  title: string;
  userId: number;
  createdAt: string;
  updatedAt: string;
}

export interface Expense {
  id: number;
  userId: number;
  amount: number; // stored in cents
  category: string;
  description: string;
  date: string;
  conversationId?: number;
}

export interface Budget {
  id: number;
  userId: number;
  total: number; // stored in cents
  categories: Record<string, number>; // category name to amount (in cents)
  month: number;
  year: number;
}

export interface BudgetSummary {
  budget: Budget;
  expenses: Expense[];
  summary: {
    totalBudget: number;
    totalSpent: number;
    remaining: number;
    percentUsed: number;
    spentByCategory: Record<string, number>;
  };
}
