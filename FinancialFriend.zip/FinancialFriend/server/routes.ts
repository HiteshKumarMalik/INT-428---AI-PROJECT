import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertMessageSchema, insertExpenseSchema, Message, Expense } from "@shared/schema";
import OpenAI from "openai";
import z from "zod";

// Initialize OpenAI client (using it for Groq model access)
const openai = new OpenAI({ 
  apiKey: process.env.GROQ_API_KEY || "", 
  baseURL: "https://api.groq.com/openai/v1" 
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Get all conversations for a user
  app.get("/api/conversations", async (req, res) => {
    try {
      const userId = 1; // Mock user ID for demo
      const conversations = await storage.getConversationsByUserId(userId);
      res.json(conversations);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch conversations" });
    }
  });

  // Get a single conversation by ID
  app.get("/api/conversations/:id", async (req, res) => {
    try {
      const conversationId = parseInt(req.params.id, 10);
      const conversation = await storage.getConversation(conversationId);
      
      if (!conversation) {
        return res.status(404).json({ message: "Conversation not found" });
      }
      
      const messages = await storage.getMessagesByConversationId(conversationId);
      res.json({ conversation, messages });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch conversation" });
    }
  });

  // Create a new conversation
  app.post("/api/conversations", async (req, res) => {
    try {
      const userId = 1; // Mock user ID for demo
      const title = req.body.title || "New Conversation";
      const conversation = await storage.createConversation({
        title,
        userId,
      });
      res.status(201).json(conversation);
    } catch (error) {
      res.status(500).json({ message: "Failed to create conversation" });
    }
  });

  // Send a message and get a response
  app.post("/api/messages", async (req, res) => {
    try {
      const messageData = insertMessageSchema.parse(req.body);
      
      // Store user message
      const userMessage = await storage.createMessage(messageData);
      
      // Process message with OpenAI and detect expenses
      const expenses = await detectExpenses(messageData.content, messageData.conversationId);
      
      // Generate AI response
      const aiResponse = await generateAIResponse(messageData.content, expenses, messageData.conversationId);
      
      // Store bot response
      const botMessage = await storage.createMessage({
        conversationId: messageData.conversationId,
        content: aiResponse,
        type: "bot",
      });
      
      // Return both messages and any extracted expenses
      res.status(201).json({
        userMessage,
        botMessage,
        expenses: expenses.length > 0 ? expenses : undefined,
      });
    } catch (error) {
      console.error("Message error:", error);
      res.status(500).json({ message: "Failed to process message" });
    }
  });

  // Get all expenses for a user
  app.get("/api/expenses", async (req, res) => {
    try {
      const userId = 1; // Mock user ID for demo
      const expenses = await storage.getExpensesByUserId(userId);
      res.json(expenses);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch expenses" });
    }
  });

  // Add a new expense
  app.post("/api/expenses", async (req, res) => {
    try {
      const expenseData = insertExpenseSchema.parse(req.body);
      const expense = await storage.createExpense(expenseData);
      res.status(201).json(expense);
    } catch (error) {
      res.status(500).json({ message: "Failed to create expense" });
    }
  });

  // Get budget summary
  app.get("/api/budget", async (req, res) => {
    try {
      const userId = 1; // Mock user ID for demo
      const date = new Date();
      const month = date.getMonth() + 1; // 1-12
      const year = date.getFullYear();
      
      // Get budget if exists, otherwise create default
      let budget = await storage.getBudgetByUserIdAndMonth(userId, month, year);
      
      if (!budget) {
        // Create a default budget
        budget = await storage.createBudget({
          userId,
          total: 250000, // $2,500.00
          categories: {
            "Food & Dining": 50000, // $500
            "Transportation": 30000, // $300
            "Housing": 100000, // $1,000
            "Entertainment": 20000, // $200
            "Other": 50000 // $500
          },
          month,
          year
        });
      }
      
      // Get expenses for current month
      const startDate = new Date(year, month - 1, 1);
      const endDate = new Date(year, month, 0);
      const expenses = await storage.getExpensesByUserIdAndDateRange(
        userId, 
        startDate.toISOString(), 
        endDate.toISOString()
      );
      
      // Calculate totals by category
      const spentByCategory: Record<string, number> = {};
      let totalSpent = 0;
      
      expenses.forEach(expense => {
        spentByCategory[expense.category] = (spentByCategory[expense.category] || 0) + expense.amount;
        totalSpent += expense.amount;
      });
      
      // Calculate budget health and remaining amounts
      const remaining = budget.total - totalSpent;
      const percentUsed = (totalSpent / budget.total) * 100;
      
      res.json({
        budget,
        expenses,
        summary: {
          totalBudget: budget.total,
          totalSpent,
          remaining,
          percentUsed,
          spentByCategory,
        }
      });
    } catch (error) {
      console.error("Budget error:", error);
      res.status(500).json({ message: "Failed to fetch budget information" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

// Helper functions
async function detectExpenses(message: string, conversationId: number): Promise<Expense[]> {
  try {
    // Analyze the message to extract expense information
    const response = await openai.chat.completions.create({
      model: "llama3-70b-8192", // Using LLaMA 3 model
      messages: [
        {
          role: "system" as const,
          content: 
            "You are an expense detector for a budgeting app. Extract expense information from the user message. " +
            "Return ONLY a JSON array of expenses. Each expense should include: amount (in cents), category (choose from: 'Food & Dining', 'Transportation', 'Housing', 'Entertainment', 'Other'), description, and date (ISO string). " +
            "Return an empty array if no expenses are mentioned. DO NOT include any explanations, just the JSON data."
        },
        {
          role: "user" as const,
          content: message
        }
      ],
      temperature: 0.1,
      response_format: { type: "json_object" }
    });

    // Parse the response
    const content = response.choices[0].message.content || "{}";
    const result = JSON.parse(content);
    const expenses = Array.isArray(result.expenses) ? result.expenses : (Array.isArray(result) ? result : []);
    
    // Store detected expenses
    const savedExpenses: Expense[] = [];
    const userId = 1; // Mock user ID
    
    for (const expense of expenses) {
      // Validate data and convert formats as needed
      if (typeof expense.amount === 'number' && expense.category && expense.description) {
        const savedExpense = await storage.createExpense({
          userId,
          amount: expense.amount,
          category: expense.category,
          description: expense.description,
          date: expense.date ? new Date(expense.date) : new Date(),
          conversationId
        });
        savedExpenses.push(savedExpense);
      }
    }
    
    return savedExpenses;
  } catch (error) {
    console.error("Error detecting expenses:", error);
    return [];
  }
}

async function generateAIResponse(
  userMessage: string, 
  detectedExpenses: Expense[], 
  conversationId: number
): Promise<string> {
  try {
    // Get conversation history
    const messages = await storage.getMessagesByConversationId(conversationId);
    
    // Get budget info for context
    const userId = 1; // Mock user ID
    const date = new Date();
    const month = date.getMonth() + 1;
    const year = date.getFullYear();
    
    const budget = await storage.getBudgetByUserIdAndMonth(userId, month, year);
    
    // Format conversation history
    const chatHistory = messages.map(msg => ({
      role: msg.type === "user" ? "user" : "assistant",
      content: msg.content
    }));
    
    // Create context about detected expenses and budget
    let expenseContext = "";
    if (detectedExpenses.length > 0) {
      expenseContext = `I just detected and saved these expenses: ${JSON.stringify(detectedExpenses.map(exp => ({
        amount: `$${(exp.amount / 100).toFixed(2)}`,
        category: exp.category,
        description: exp.description,
        date: new Date(exp.date).toLocaleDateString()
      })))}. `;
    }
    
    let budgetContext = "";
    if (budget) {
      budgetContext = `The user's monthly budget is $${(budget.total / 100).toFixed(2)}.`;
    }
    
    // Create the Groq prompt
    // Format history correctly with explicitly typed roles
    const typedChatHistory = chatHistory.map(msg => ({
      role: msg.role === "user" ? "user" as const : "assistant" as const,
      content: msg.content
    }));
    
    const response = await openai.chat.completions.create({
      model: "llama3-70b-8192", // Using LLaMA 3 model
      messages: [
        {
          role: "system" as const,
          content: 
            "You are BudgetBot, an AI-powered financial assistant. You help users track expenses, analyze budgets, and provide financial insights. " +
            "You are friendly, helpful, and focused on providing actionable financial advice. " +
            expenseContext + budgetContext + " " +
            "If the user is asking for a budget analysis, provide a detailed breakdown of their spending. " +
            "If they're adding expenses, confirm what you've recorded. " +
            "Keep responses concise, friendly, and focused on helping the user manage their finances."
        },
        ...typedChatHistory.slice(-10), // Include last 10 messages for context
        {
          role: "user" as const,
          content: userMessage
        }
      ],
      temperature: 0.4
    });

    return response.choices[0].message.content || "I'm sorry, I couldn't process that request.";
  } catch (error) {
    console.error("Error generating AI response:", error);
    return "I'm having trouble responding right now. Please try again later.";
  }
}
